$(document).ready(function () {
  pageHeight();
  fixSidebarOnScroll();
  $(window).resize(function () {
    pageHeight();
    fixSidebarOnScroll();
  });
  function pageHeight() {
    $(".login .page-content").css(
      "min-height",
      "calc(100vh - " + $(".page-footer").outerHeight() + "px)"
    );
    if (
      document.querySelector(".side-nav") !== null &&
      document.querySelector(".content-wrapper-main") !== null
    ) {
      $(".side-nav, .content-wrapper-main").css(
        "height",
        "calc(100vh - " + $(".custom-nav").outerHeight() + "px)"
      );
      $(".content-wrapper-main").css(
        "width",
        "calc(100% - " + $(".side-nav").outerWidth() + "px)"
      );
    }
    if (document.querySelector(".content-body") !== null) {
      $(".content-body").css(
        "min-height",
        "calc(100vh - " +
          ($(".custom-nav").outerHeight() + $(".page-footer").outerHeight()) +
          "px)"
      );
    }
    $(".side-nav").css(
      "height",
      "calc(100vh - " + $(".custom-nav").outerHeight() + "px)"
    );

    if ($(window).width() < 1199) {
      $("body").addClass("small-side-nav");
      $(".content-wrapper-main").css("width", "calc(100% - " + "72px)");
    } else {
      $("body").removeClass("small-side-nav");
      $(".content-wrapper-main").css(
        "width",
        "calc(100% - " + $(".side-nav").outerWidth() + "px)"
      );
    }
  }

  $(".sidebar-toogle").click(function () {
    $("body").toggleClass("small-side-nav");
    $(".content-wrapper-main").css("width", "calc(100% - " + "72px)");
  });

  var $sidebar = $(".left-sec");

  console.log($sidebar, "ad");
  var sidebarTop = $sidebar.position().top;
  console.log(sidebarTop, "sidebarTop");

  var rightSec = $(".right-sec").outerHeight() - 10;
  console.log(rightSec, "rightSec");

  $(".content-wrapper-main").scroll(function () {
    fixSidebarOnScroll();
  });

  function fixSidebarOnScroll() {
    var windowScrollTop = $(".content-wrapper-main").scrollTop();
    if (windowScrollTop >= rightSec || windowScrollTop <= sidebarTop) {
      // Remove when the scroll is greater than our #content.OuterHeight()
      // or when our sticky scroll is above the original position of the sidebar
      $sidebar.removeClass("sticky");
      console.log("if");
    } else if (windowScrollTop >= sidebarTop) {
        console.log("elsepart");
      // Otherwise add the sticky if $sidebar doesnt have it already!
      if (!$sidebar.hasClass("sticky")) {
        $sidebar.addClass("sticky");
        console.log("ifelsepart");
      }
    }
  }
});
